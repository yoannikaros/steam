import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:steam/providers/auth_provider.dart';
import 'package:steam/screens/login_screen.dart';
import 'package:steam/screens/customer/customer_list_screen.dart';
import 'package:steam/screens/service/service_list_screen.dart';
import 'package:steam/screens/order/order_list_screen.dart';
import 'package:steam/screens/payment/payment_list_screen.dart';
import 'package:steam/screens/transaction/transaction_list_screen.dart';
import 'package:steam/screens/saving/saving_list_screen.dart';
import 'package:steam/screens/setting/setting_screen.dart';
import 'package:steam/screens/report/report_screen.dart';
import 'package:steam/screens/user/user_list_screen.dart';
import 'package:steam/repositories/order_repository.dart';
import 'package:steam/repositories/transaction_repository.dart';
import 'package:intl/intl.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final OrderRepository _orderRepository = OrderRepository();
  final TransactionRepository _transactionRepository = TransactionRepository();
  
  int _waitingOrders = 0;
  int _inProgressOrders = 0;
  int _doneOrders = 0;
  Map<String, double> _financialSummary = {
    'income': 0,
    'expense': 0,
    'profit': 0,
  };

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
    
    final waitingOrders = await _orderRepository.getOrdersByStatus('waiting');
    final inProgressOrders = await _orderRepository.getOrdersByStatus('in_progress');
    final doneOrders = await _orderRepository.getOrdersByStatus('done');
    
    final firstDayOfMonth = DateTime(DateTime.now().year, DateTime.now().month, 1);
    final lastDayOfMonth = DateTime(DateTime.now().year, DateTime.now().month + 1, 0);
    
    final startDate = DateFormat('yyyy-MM-dd').format(firstDayOfMonth);
    final endDate = DateFormat('yyyy-MM-dd').format(lastDayOfMonth);
    
    final summary = await _transactionRepository.getSummary(startDate, endDate);
    
    setState(() {
      _waitingOrders = waitingOrders.length;
      _inProgressOrders = inProgressOrders.length;
      _doneOrders = doneOrders.length;
      _financialSummary = summary;
    });
  }

  void _logout() {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    authProvider.logout();
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);
    final user = authProvider.currentUser;
    final currencyFormat = NumberFormat.currency(
      locale: 'id',
      symbol: 'Rp ',
      decimalDigits: 0,
    );

    return Scaffold(
      appBar: AppBar(
        title: Text('Aplikasi Cuci Motor'),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: _logout,
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            UserAccountsDrawerHeader(
              accountName: Text(user?.username ?? 'User'),
              accountEmail: Text(user?.role ?? 'Role'),
              currentAccountPicture: CircleAvatar(
                child: Icon(Icons.person),
              ),
            ),
            ListTile(
              leading: Icon(Icons.dashboard),
              title: Text('Dashboard'),
              onTap: () {
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Icon(Icons.people),
              title: Text('Pelanggan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => CustomerListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.cleaning_services),
              title: Text('Layanan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ServiceListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.receipt_long),
              title: Text('Pesanan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => OrderListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.payment),
              title: Text('Pembayaran'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => PaymentListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.account_balance_wallet),
              title: Text('Transaksi'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => TransactionListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.savings),
              title: Text('Tabungan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => SavingListScreen()),
                );
              },
            ),
            ListTile(
              leading: Icon(Icons.bar_chart),
              title: Text('Laporan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => ReportScreen()),
                );
              },
            ),
            if (user?.role == 'admin')
              ListTile(
                leading: Icon(Icons.person),
                title: Text('Pengguna'),
                onTap: () {
                  Navigator.pop(context);
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => UserListScreen()),
                  );
                },
              ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Pengaturan'),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => SettingScreen()),
                );
              },
            ),
          ],
        ),
      ),
      body: RefreshIndicator(
        onRefresh: _loadData,
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Selamat Datang, ${user?.username ?? 'User'}!',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),
              Text(
                'Ringkasan Pesanan Hari Ini',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: _buildStatusCard(
                      'Menunggu',
                      _waitingOrders.toString(),
                      Colors.orange,
                      Icons.hourglass_empty,
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: _buildStatusCard(
                      'Proses',
                      _inProgressOrders.toString(),
                      Colors.blue,
                      Icons.directions_car,
                    ),
                  ),
                  SizedBox(width: 8),
                  Expanded(
                    child: _buildStatusCard(
                      'Selesai',
                      _doneOrders.toString(),
                      Colors.green,
                      Icons.check_circle,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 24),
              Text(
                'Ringkasan Keuangan Bulan Ini',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16),
              Card(
                elevation: 2,
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _buildFinancialItem(
                        'Pemasukan',
                        currencyFormat.format(_financialSummary['income']),
                        Colors.green,
                        Icons.arrow_upward,
                      ),
                      Divider(),
                      _buildFinancialItem(
                        'Pengeluaran',
                        currencyFormat.format(_financialSummary['expense']),
                        Colors.red,
                        Icons.arrow_downward,
                      ),
                      Divider(),
                      _buildFinancialItem(
                        'Keuntungan',
                        currencyFormat.format(_financialSummary['profit']),
                        Colors.blue,
                        Icons.account_balance,
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 24),
              Text(
                'Menu Cepat',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 16),
              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                children: [
                  _buildQuickMenu(
                    'Pesanan Baru',
                    Icons.add_circle,
                    Colors.blue,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => OrderListScreen(initialTabIndex: 1),
                        ),
                      );
                    },
                  ),
                  _buildQuickMenu(
                    'Pelanggan Baru',
                    Icons.person_add,
                    Colors.green,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => CustomerListScreen(showAddForm: true),
                        ),
                      );
                    },
                  ),
                  _buildQuickMenu(
                    'Transaksi Baru',
                    Icons.post_add,
                    Colors.orange,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => TransactionListScreen(showAddForm: true),
                        ),
                      );
                    },
                  ),
                  _buildQuickMenu(
                    'Laporan',
                    Icons.bar_chart,
                    Colors.purple,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => ReportScreen()),
                      );
                    },
                  ),
                  _buildQuickMenu(
                    'Pengaturan',
                    Icons.settings,
                    Colors.grey,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => SettingScreen()),
                      );
                    },
                  ),
                  _buildQuickMenu(
                    'Tabungan',
                    Icons.savings,
                    Colors.teal,
                    () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) => SavingListScreen()),
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusCard(String title, String value, Color color, IconData icon) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(
              icon,
              color: color,
              size: 32,
            ),
            SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFinancialItem(String title, String value, Color color, IconData icon) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(
            icon,
            color: color,
            size: 24,
          ),
          SizedBox(width: 16),
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
            ),
          ),
          Spacer(),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickMenu(String title, IconData icon, Color color, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: color.withOpacity(0.3),
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              color: color,
              size: 32,
            ),
            SizedBox(height: 8),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
