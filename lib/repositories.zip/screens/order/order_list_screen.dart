import 'package:flutter/material.dart';
import 'package:steam/repositories/order_repository.dart';
import 'package:steam/screens/order/order_form_screen.dart';
import 'package:steam/screens/order/order_detail_screen.dart';
import 'package:intl/intl.dart';

class OrderListScreen extends StatefulWidget {
  final int initialTabIndex;

  OrderListScreen({this.initialTabIndex = 0});

  @override
  _OrderListScreenState createState() => _OrderListScreenState();
}

class _OrderListScreenState extends State<OrderListScreen> with SingleTickerProviderStateMixin {
  final OrderRepository _orderRepository = OrderRepository();
  List<Map<String, dynamic>> _orders = [];
  bool _isLoading = true;
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this, initialIndex: widget.initialTabIndex);
    _loadOrders();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadOrders() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final orders = await _orderRepository.getOrdersWithDetails();
      setState(() {
        _orders = orders;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  List<Map<String, dynamic>> _getFilteredOrders(String status) {
    if (status == 'all') {
      return _orders;
    }
    return _orders.where((order) => order['status'] == status).toList();
  }

  Future<void> _navigateToAddOrder() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => OrderFormScreen(),
      ),
    );

    if (result != null && result) {
      _loadOrders();
    }
  }

  Future<void> _navigateToOrderDetail(Map<String, dynamic> order) async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => OrderDetailScreen(orderId: order['id']),
      ),
    );

    if (result != null && result) {
      _loadOrders();
    }
  }

  Future<void> _updateOrderStatus(int id, String status) async {
    try {
      await _orderRepository.updateOrderStatus(id, status);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Status pesanan berhasil diperbarui'),
          backgroundColor: Colors.green,
        ),
      );
      _loadOrders();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _deleteOrder(int id) async {
    try {
      await _orderRepository.deleteOrder(id);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Pesanan berhasil dihapus'),
          backgroundColor: Colors.green,
        ),
      );
      _loadOrders();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(
      locale: 'id',
      symbol: 'Rp ',
      decimalDigits: 0,
    );

    return Scaffold(
      appBar: AppBar(
        title: Text('Daftar Pesanan'),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Semua'),
            Tab(text: 'Menunggu'),
            Tab(text: 'Proses'),
            Tab(text: 'Selesai'),
          ],
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabController,
              children: [
                _buildOrderList(_getFilteredOrders('all'), currencyFormat),
                _buildOrderList(_getFilteredOrders('waiting'), currencyFormat),
                _buildOrderList(_getFilteredOrders('in_progress'), currencyFormat),
                _buildOrderList(_getFilteredOrders('done'), currencyFormat),
              ],
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _navigateToAddOrder,
        child: Icon(Icons.add),
        tooltip: 'Tambah Pesanan',
      ),
    );
  }

  Widget _buildOrderList(List<Map<String, dynamic>> orders, NumberFormat currencyFormat) {
    if (orders.isEmpty) {
      return Center(child: Text('Tidak ada data pesanan'));
    }

    return RefreshIndicator(
      onRefresh: _loadOrders,
      child: ListView.builder(
        itemCount: orders.length,
        itemBuilder: (context, index) {
          final order = orders[index];
          return Card(
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: ListTile(
              title: Text(
                order['service_name'] ?? 'Layanan tidak ditemukan',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('${order['date']} ${order['time']}'),
                  Text(
                    'Pelanggan: ${order['customer_name'] ?? 'Pelanggan umum'}',
                  ),
                  Row(
                    children: [
                      _buildStatusBadge(order['status']),
                      SizedBox(width: 8),
                      _buildPaymentBadge(order['is_paid']),
                    ],
                  ),
                ],
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    currencyFormat.format(order['total_price'] ?? order['service_price']),
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(width: 8),
                  PopupMenuButton(
                    icon: Icon(Icons.more_vert),
                    onSelected: (value) {
                      if (value == 'detail') {
                        _navigateToOrderDetail(order);
                      } else if (value == 'status') {
                        _showStatusUpdateDialog(order);
                      } else if (value == 'delete') {
                        _showDeleteConfirmationDialog(order);
                      }
                    },
                    itemBuilder: (context) => [
                      PopupMenuItem(
                        value: 'detail',
                        child: Row(
                          children: [
                            Icon(Icons.info, color: Colors.blue),
                            SizedBox(width: 8),
                            Text('Detail'),
                          ],
                        ),
                      ),
                      PopupMenuItem(
                        value: 'status',
                        child: Row(
                          children: [
                            Icon(Icons.update, color: Colors.orange),
                            SizedBox(width: 8),
                            Text('Ubah Status'),
                          ],
                        ),
                      ),
                      PopupMenuItem(
                        value: 'delete',
                        child: Row(
                          children: [
                            Icon(Icons.delete, color: Colors.red),
                            SizedBox(width: 8),
                            Text('Hapus'),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              onTap: () => _navigateToOrderDetail(order),
              onLongPress: () {
                if (order['status'] == 'waiting') {
                  _showStatusUpdateDialog(order);
                }
              },
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatusBadge(String status) {
    Color color;
    String text;

    switch (status) {
      case 'waiting':
        color = Colors.orange;
        text = 'Menunggu';
        break;
      case 'in_progress':
        color = Colors.blue;
        text = 'Diproses';
        break;
      case 'done':
        color = Colors.green;
        text = 'Selesai';
        break;
      case 'cancelled':
        color = Colors.red;
        text = 'Batal';
        break;
      default:
        color = Colors.grey;
        text = status;
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildPaymentBadge(int isPaid) {
    Color color = isPaid == 1 ? Colors.green : Colors.red;
    String text = isPaid == 1 ? 'Lunas' : 'Belum Bayar';

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  void _showStatusUpdateDialog(Map<String, dynamic> order) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Perbarui Status'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Pilih status baru untuk pesanan ini:'),
            SizedBox(height: 16),
            ListTile(
              title: Text('Sedang Diproses'),
              leading: Icon(Icons.directions_car, color: Colors.blue),
              onTap: () {
                Navigator.pop(context);
                _updateOrderStatus(order['id'], 'in_progress');
              },
            ),
            ListTile(
              title: Text('Selesai'),
              leading: Icon(Icons.check_circle, color: Colors.green),
              onTap: () {
                Navigator.pop(context);
                _updateOrderStatus(order['id'], 'done');
              },
            ),
            ListTile(
              title: Text('Dibatalkan'),
              leading: Icon(Icons.cancel, color: Colors.red),
              onTap: () {
                Navigator.pop(context);
                _updateOrderStatus(order['id'], 'cancelled');
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
        ],
      ),
    );
  }

  void _showDeleteConfirmationDialog(Map<String, dynamic> order) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Konfirmasi Hapus'),
        content: Text('Apakah Anda yakin ingin menghapus pesanan ini? Tindakan ini tidak dapat dibatalkan.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _deleteOrder(order['id']);
            },
            child: Text('Hapus'),
            style: TextButton.styleFrom(
              foregroundColor: Colors.red,
            ),
          ),
        ],
      ),
    );
  }
}
