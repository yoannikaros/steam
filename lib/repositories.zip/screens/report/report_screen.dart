import 'package:flutter/material.dart';
import 'package:steam/repositories/transaction_repository.dart';
import 'package:steam/repositories/order_repository.dart';
import 'package:steam/repositories/saving_repository.dart';
import 'package:intl/intl.dart';

class ReportScreen extends StatefulWidget {
  @override
  _ReportScreenState createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> with SingleTickerProviderStateMixin {
  final TransactionRepository _transactionRepository = TransactionRepository();
  final OrderRepository _orderRepository = OrderRepository();
  final SavingRepository _savingRepository = SavingRepository();
  
  late TabController _tabController;
  
  DateTime _startDate = DateTime.now().subtract(Duration(days: 30));
  DateTime _endDate = DateTime.now();
  
  Map<String, double> _financialSummary = {
    'income': 0,
    'expense': 0,
    'profit': 0,
  };
  
  List<Map<String, dynamic>> _orders = [];
  double _totalSavings = 0;
  
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadReportData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadReportData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final startDateStr = DateFormat('yyyy-MM-dd').format(_startDate);
      final endDateStr = DateFormat('yyyy-MM-dd').format(_endDate);
      
      final summary = await _transactionRepository.getSummary(startDateStr, endDateStr);
      final orders = await _orderRepository.getOrdersWithDetails();
      final totalSavings = await _savingRepository.getTotalSavings();
      
      // Filter orders by date range
      final filteredOrders = orders.where((order) {
        try {
          final orderDate = DateFormat('yyyy-MM-dd').parse(order['date']);
          return orderDate.isAfter(_startDate.subtract(Duration(days: 1))) && 
                 orderDate.isBefore(_endDate.add(Duration(days: 1)));
        } catch (e) {
          return false;
        }
      }).toList();
      
      setState(() {
        _financialSummary = summary;
        _orders = filteredOrders;
        _totalSavings = totalSavings;
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _selectStartDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _startDate,
      firstDate: DateTime.now().subtract(Duration(days: 365)),
      lastDate: _endDate,
    );
    if (picked != null && picked != _startDate) {
      setState(() {
        _startDate = picked;
      });
      _loadReportData();
    }
  }

  Future<void> _selectEndDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _endDate,
      firstDate: _startDate,
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _endDate) {
      setState(() {
        _endDate = picked;
      });
      _loadReportData();
    }
  }

  @override
  Widget build(BuildContext context) {
    final currencyFormat = NumberFormat.currency(
      locale: 'id',
      symbol: 'Rp ',
      decimalDigits: 0,
    );

    return Scaffold(
      appBar: AppBar(
        title: Text('Laporan'),
        bottom: TabBar(
          controller: _tabController,
          tabs: [
            Tab(text: 'Keuangan'),
            Tab(text: 'Pesanan'),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: InkWell(
                    onTap: () => _selectStartDate(context),
                    child: InputDecorator(
                      decoration: InputDecoration(
                        labelText: 'Dari Tanggal',
                        border: OutlineInputBorder(),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(DateFormat('dd/MM/yyyy').format(_startDate)),
                          Icon(Icons.calendar_today),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: InkWell(
                    onTap: () => _selectEndDate(context),
                    child: InputDecorator(
                      decoration: InputDecoration(
                        labelText: 'Sampai Tanggal',
                        border: OutlineInputBorder(),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(DateFormat('dd/MM/yyyy').format(_endDate)),
                          Icon(Icons.calendar_today),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: _isLoading
                ? Center(child: CircularProgressIndicator())
                : TabBarView(
                    controller: _tabController,
                    children: [
                      _buildFinancialReport(currencyFormat),
                      _buildOrderReport(currencyFormat),
                    ],
                  ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _exportReport,
        child: Icon(Icons.download),
        tooltip: 'Ekspor Laporan',
      ),
    );
  }

  Widget _buildFinancialReport(NumberFormat currencyFormat) {
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ringkasan Keuangan',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 16),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  _buildFinancialItem(
                    'Pemasukan',
                    currencyFormat.format(_financialSummary['income']),
                    Colors.green,
                    Icons.arrow_upward,
                  ),
                  Divider(),
                  _buildFinancialItem(
                    'Pengeluaran',
                    currencyFormat.format(_financialSummary['expense']),
                    Colors.red,
                    Icons.arrow_downward,
                  ),
                  Divider(),
                  _buildFinancialItem(
                    'Keuntungan',
                    currencyFormat.format(_financialSummary['profit']),
                    Colors.blue,
                    Icons.account_balance,
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 24),
          Text(
            'Tabungan',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 16),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(
                    Icons.savings,
                    size: 48,
                    color: Colors.blue,
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Total Tabungan',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[700],
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          currencyFormat.format(_totalSavings),
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: _totalSavings >= 0 ? Colors.blue : Colors.red,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 24),
          Text(
            'Periode Laporan',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 16),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildInfoRow('Dari Tanggal', DateFormat('dd MMMM yyyy', 'id').format(_startDate)),
                  SizedBox(height: 8),
                  _buildInfoRow('Sampai Tanggal', DateFormat('dd MMMM yyyy', 'id').format(_endDate)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderReport(NumberFormat currencyFormat) {
    // Calculate order statistics
    int totalOrders = _orders.length;
    int completedOrders = _orders.where((order) => order['status'] == 'done').length;
    int cancelledOrders = _orders.where((order) => order['status'] == 'cancelled').length;
    int inProgressOrders = _orders.where((order) => order['status'] == 'in_progress').length;
    int waitingOrders = _orders.where((order) => order['status'] == 'waiting').length;
    double totalRevenue = 0;
    
    for (var order in _orders) {
      if (order['status'] == 'done') {
        totalRevenue += (order['total_price'] ?? order['service_price']) as double;
      }
    }
    
    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Ringkasan Pesanan',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _buildStatCard('Total Pesanan', totalOrders.toString(), Colors.blue),
              ),
              SizedBox(width: 8),
              Expanded(
                child: _buildStatCard('Selesai', completedOrders.toString(), Colors.green),
              ),
            ],
          ),
          SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _buildStatCard('Menunggu', waitingOrders.toString(), Colors.orange),
              ),
              SizedBox(width: 8),
              Expanded(
                child: _buildStatCard('Diproses', inProgressOrders.toString(), Colors.purple),
              ),
              SizedBox(width: 8),
              Expanded(
                child: _buildStatCard('Dibatalkan', cancelledOrders.toString(), Colors.red),
              ),
            ],
          ),
          SizedBox(height: 16),
          Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(
                    Icons.payments,
                    size: 48,
                    color: Colors.green,
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Total Pendapatan',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey[700],
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          currencyFormat.format(totalRevenue),
                          style: TextStyle(
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            color: Colors.green,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 24),
          Text(
            'Daftar Pesanan',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 16),
          _orders.isEmpty
              ? Center(
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Text('Tidak ada data pesanan'),
                  ),
                )
              : ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: _orders.length,
                  itemBuilder: (context, index) {
                    final order = _orders[index];
                    return Card(
                      margin: EdgeInsets.only(bottom: 8),
                      child: ListTile(
                        title: Text(
                          order['service_name'] ?? 'Layanan tidak ditemukan',
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('${order['date']} ${order['time']}'),
                            Text(
                              'Pelanggan: ${order['customer_name'] ?? 'Pelanggan umum'}',
                            ),
                            Row(
                              children: [
                                _buildStatusBadge(order['status']),
                                SizedBox(width: 8),
                                _buildPaymentBadge(order['is_paid']),
                              ],
                            ),
                          ],
                        ),
                        trailing: Text(
                          currencyFormat.format(order['total_price'] ?? order['service_price']),
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        onTap: () {
                          Navigator.pushNamed(
                            context,
                            '/order-detail',
                            arguments: order['id'],
                          );
                        },
                      ),
                    );
                  },
                ),
        ],
      ),
    );
  }

  Widget _buildFinancialItem(String title, String value, Color color, IconData icon) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Icon(
            icon,
            color: color,
            size: 24,
          ),
          SizedBox(width: 16),
          Text(
            title,
            style: TextStyle(
              fontSize: 16,
            ),
          ),
          Spacer(),
          Text(
            value,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(String title, String value, Color color) {
    return Card(
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            SizedBox(height: 4),
            Text(
              title,
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[600],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusBadge(String status) {
    Color color;
    String text;

    switch (status) {
      case 'waiting':
        color = Colors.orange;
        text = 'Menunggu';
        break;
      case 'in_progress':
        color = Colors.blue;
        text = 'Diproses';
        break;
      case 'done':
        color = Colors.green;
        text = 'Selesai';
        break;
      case 'cancelled':
        color = Colors.red;
        text = 'Batal';
        break;
      default:
        color = Colors.grey;
        text = status;
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildPaymentBadge(int isPaid) {
    Color color = isPaid == 1 ? Colors.green : Colors.red;
    String text = isPaid == 1 ? 'Lunas' : 'Belum Bayar';

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: color),
      ),
      child: Text(
        text,
        style: TextStyle(
          fontSize: 12,
          color: color,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 120,
          child: Text(
            label,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.grey[700],
            ),
          ),
        ),
        Expanded(
          child: Text(value),
        ),
      ],
    );
  }

  void _exportReport() {
    // Tampilkan dialog pilihan ekspor
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Ekspor Laporan'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Pilih format ekspor laporan:'),
            SizedBox(height: 16),
            ListTile(
              title: Text('PDF'),
              leading: Icon(Icons.picture_as_pdf, color: Colors.red),
              onTap: () {
                Navigator.pop(context);
                _showExportMessage('PDF');
              },
            ),
            ListTile(
              title: Text('Excel'),
              leading: Icon(Icons.table_chart, color: Colors.green),
              onTap: () {
                Navigator.pop(context);
                _showExportMessage('Excel');
              },
            ),
            ListTile(
              title: Text('CSV'),
              leading: Icon(Icons.description, color: Colors.blue),
              onTap: () {
                Navigator.pop(context);
                _showExportMessage('CSV');
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Batal'),
          ),
        ],
      ),
    );
  }

  void _showExportMessage(String format) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Laporan berhasil diekspor dalam format $format'),
        backgroundColor: Colors.green,
      ),
    );
  }
}
