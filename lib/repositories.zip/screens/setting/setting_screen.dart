import 'package:flutter/material.dart';
import 'package:steam/models/setting.dart';
import 'package:steam/repositories/setting_repository.dart';

class SettingScreen extends StatefulWidget {
  @override
  _SettingScreenState createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  final _formKey = GlobalKey<FormState>();
  final _businessNameController = TextEditingController();
  final _noteHeaderController = TextEditingController();
  final _noteFooterController = TextEditingController();
  
  final SettingRepository _settingRepository = SettingRepository();
  
  bool _isLoading = true;
  bool _isSaving = false;
  Setting? _setting;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  @override
  void dispose() {
    _businessNameController.dispose();
    _noteHeaderController.dispose();
    _noteFooterController.dispose();
    super.dispose();
  }

  Future<void> _loadSettings() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final setting = await _settingRepository.getSettings();
      
      setState(() {
        _setting = setting;
        _businessNameController.text = setting.businessName ?? '';
        _noteHeaderController.text = setting.noteHeader ?? '';
        _noteFooterController.text = setting.noteFooter ?? '';
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _isLoading = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _saveSettings() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      final setting = Setting(
        id: _setting?.id,
        businessName: _businessNameController.text.trim(),
        noteHeader: _noteHeaderController.text.trim(),
        noteFooter: _noteFooterController.text.trim(),
      );

      await _settingRepository.updateSettings(setting);
      
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Pengaturan berhasil disimpan'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() {
        _isSaving = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Pengaturan'),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: EdgeInsets.all(16),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Pengaturan Usaha',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 16),
                            TextFormField(
                              controller: _businessNameController,
                              decoration: InputDecoration(
                                labelText: 'Nama Usaha',
                                border: OutlineInputBorder(),
                              ),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return 'Nama usaha tidak boleh kosong';
                                }
                                return null;
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 16),
                    Card(
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Pengaturan Nota',
                              style: TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            SizedBox(height: 16),
                            TextFormField(
                              controller: _noteHeaderController,
                              decoration: InputDecoration(
                                labelText: 'Header Nota',
                                border: OutlineInputBorder(),
                                hintText: 'Contoh: Terima kasih telah menggunakan jasa kami',
                              ),
                              maxLines: 2,
                            ),
                            SizedBox(height: 16),
                            TextFormField(
                              controller: _noteFooterController,
                              decoration: InputDecoration(
                                labelText: 'Footer Nota',
                                border: OutlineInputBorder(),
                                hintText: 'Contoh: Silahkan datang kembali',
                              ),
                              maxLines: 2,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 24),
                    SizedBox(
                      height: 50,
                      child: ElevatedButton(
                        onPressed: _isSaving ? null : _saveSettings,
                        child: _isSaving
                            ? CircularProgressIndicator()
                            : Text('Simpan Pengaturan'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}
